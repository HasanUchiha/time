import React from 'react';
import ActivityItem from './ActivityItem';

const ActivityList = ({ activities, tags, updateActivity }) => {
  if (!activities || activities.length === 0) {
    return <p>No activities to display</p>;
  }

  return (
    <div className="task-list">
      {activities.map((activity) => (
        <ActivityItem
          key={activity.id}
          activity={activity}
          tags={tags}
          updateActivity={updateActivity}
        />
      ))}
    </div>
  );
};

export default ActivityList;
