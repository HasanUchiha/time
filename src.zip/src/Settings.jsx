import React from 'react';

const Settings = () => {
  return (
    <div className="settings">
      <h1>Settings</h1>
      <p>Here you can customize the app settings (coming soon).</p>
    </div>
  );
};

export default Settings;
