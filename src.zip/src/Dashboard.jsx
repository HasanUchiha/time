import React, { useState, useEffect } from 'react';
import ActivityForm from './ActivityForm';
import ActivityList from './ActivityList';

const Dashboard = () => {
  const [activities, setActivities] = useState([]);
  const [tags, setTags] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const tasksResponse = await fetch('http://127.0.0.1:3010/tasks');
        if (!tasksResponse.ok) {
          throw new Error('Failed to fetch tasks');
        }
        const tasks = await tasksResponse.json();

        const tagsResponse = await fetch('http://127.0.0.1:3010/tags');
        if (!tagsResponse.ok) {
          throw new Error('Failed to fetch tags');
        }
        const tagsData = await tagsResponse.json();

        const tagMap = tagsData.reduce((map, tag) => {
          map[tag.id] = tag.name;
          return map;
        }, {});

        setActivities(tasks);
        setTags(tagMap);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const addActivity = (activity) => {
    setActivities([...activities, activity]);
  };

  const updateActivity = (updatedActivity) => {
    setActivities(
      activities.map((activity) =>
        activity.id === updatedActivity.id ? updatedActivity : activity
      )
    );
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <ActivityForm addActivity={addActivity} />
      <ActivityList activities={activities} tags={tags} updateActivity={updateActivity} />
    </div>
  );
};

export default Dashboard;
