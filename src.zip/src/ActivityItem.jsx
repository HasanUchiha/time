import React from 'react';

const ActivityItem = ({ activity, updateActivity, tags }) => {
  const handleStop = () => {
    const endTime = new Date();
    const duration = activity.startTime
      ? (endTime - new Date(activity.startTime)) / (1000 * 60)
      : 0;

    updateActivity({ ...activity, endTime, duration });
  };

  const readableTags = activity.tags
    ? activity.tags
        .split(',')
        .map((id) => tags[id] || `Tag ${id}`)
        .join(', ')
    : 'No tags';

  return (
    <div className="task-element">
      <h3 className="task-name">{activity.name}</h3>
      <div className="task-tags">
        {readableTags.split(', ').map((tag, idx) => (
          <span key={idx} className="tag-badge">
            {tag}
          </span>
        ))}
      </div>
      {activity.startTime ? (
        <p>Start Time: {new Date(activity.startTime).toLocaleString()}</p>
      ) : (
        <p>Start Time: Not Started</p>
      )}
      {activity.endTime ? (
        <p>
          End Time: {new Date(activity.endTime).toLocaleString()} <br />
          Duration: {activity.duration?.toFixed(2)} minutes
        </p>
      ) : (
        activity.startTime && <button onClick={handleStop}>Stop</button>
      )}
    </div>
  );
};

export default ActivityItem;
